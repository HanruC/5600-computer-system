#ifndef MPG2KM_H
#define MPG2KM_H

double mpg2kml(double mpg);
double mpg2lphm(double mpg);
double lph2mpg(double lph);

#endif 
